import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, FlatList, ActivityIndicator } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import axios from 'axios';

const Tab = createBottomTabNavigator();

// AI 对话屏幕
function ChatScreen() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [apiConfig, setApiConfig] = useState(null);

  useEffect(() => {
    loadApiConfig();
  }, []);

  const loadApiConfig = async () => {
    // 从本地存储加载 API 配置
    try {
      const config = await AsyncStorage.getItem('apiConfig');
      if (config) {
        setApiConfig(JSON.parse(config));
      }
    } catch (e) {
      console.log('加载配置失败');
    }
  };

  const sendMessage = async () => {
    if (!input.trim() || !apiConfig) {
      alert('请先配置 API');
      return;
    }

    const userMessage = { role: 'user', content: input };
    setMessages([...messages, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const response = await axios.post(
        `${apiConfig.endpoint}/chat/completions`,
        {
          model: apiConfig.model,
          messages: [...messages, userMessage],
        },
        {
          headers: {
            'Authorization': `Bearer ${apiConfig.apiKey}`,
            'Content-Type': 'application/json',
          },
        }
      );

      const aiMessage = {
        role: 'assistant',
        content: response.data.choices[0].message.content,
      };
      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      alert('发送失败：' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>AI 对话</Text>
      <FlatList
        data={messages}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <View style={[styles.messageBubble, item.role === 'user' ? styles.userMessage : styles.aiMessage]}>
            <Text style={styles.messageText}>{item.content}</Text>
          </View>
        )}
        style={styles.messageList}
      />
      {loading && <ActivityIndicator size="large" color="#0A7EA4" />}
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="输入消息..."
          value={input}
          onChangeText={setInput}
          editable={!loading}
        />
        <TouchableOpacity style={styles.sendButton} onPress={sendMessage} disabled={loading}>
          <Text style={styles.sendButtonText}>发送</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

// API 设置屏幕
function SettingsScreen() {
  const [endpoint, setEndpoint] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [model, setModel] = useState('');
  const [models, setModels] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const config = await AsyncStorage.getItem('apiConfig');
      if (config) {
        const parsed = JSON.parse(config);
        setEndpoint(parsed.endpoint);
        setApiKey(parsed.apiKey);
        setModel(parsed.model);
      }
    } catch (e) {
      console.log('加载设置失败');
    }
  };

  const getModels = async () => {
    if (!endpoint || !apiKey) {
      alert('请填写 API 端点和密钥');
      return;
    }

    setLoading(true);
    try {
      const response = await axios.get(
        `${endpoint}/models`,
        {
          headers: {
            'Authorization': `Bearer ${apiKey}`,
          },
        }
      );
      setModels(response.data.data || []);
    } catch (error) {
      alert('获取模型列表失败：' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async () => {
    if (!endpoint || !apiKey || !model) {
      alert('请填写所有字段');
      return;
    }

    try {
      const config = { endpoint, apiKey, model };
      await AsyncStorage.setItem('apiConfig', JSON.stringify(config));
      alert('设置已保存');
    } catch (e) {
      alert('保存失败');
    }
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>API 设置</Text>
      
      <Text style={styles.label}>API 端点</Text>
      <TextInput
        style={styles.input}
        placeholder="https://api.openai.com/v1"
        value={endpoint}
        onChangeText={setEndpoint}
      />

      <Text style={styles.label}>API 密钥</Text>
      <TextInput
        style={styles.input}
        placeholder="sk-..."
        value={apiKey}
        onChangeText={setApiKey}
        secureTextEntry
      />

      <TouchableOpacity style={styles.button} onPress={getModels} disabled={loading}>
        <Text style={styles.buttonText}>{loading ? '加载中...' : '获取模型列表'}</Text>
      </TouchableOpacity>

      {models.length > 0 && (
        <>
          <Text style={styles.label}>选择模型</Text>
          <FlatList
            data={models}
            keyExtractor={(item) => item.id}
            scrollEnabled={false}
            renderItem={({ item }) => (
              <TouchableOpacity
                style={[styles.modelItem, model === item.id && styles.selectedModel]}
                onPress={() => setModel(item.id)}
              >
                <Text style={styles.modelText}>{item.id}</Text>
              </TouchableOpacity>
            )}
          />
        </>
      )}

      <TouchableOpacity style={styles.button} onPress={saveSettings}>
        <Text style={styles.buttonText}>保存设置</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

// Shizuku 屏幕
function ShizukuScreen() {
  const [authorized, setAuthorized] = useState(false);
  const [command, setCommand] = useState('');
  const [output, setOutput] = useState('');

  const checkAuthorization = () => {
    // 模拟检查授权状态
    setAuthorized(true);
    alert('Shizuku 已授权');
  };

  const executeCommand = async () => {
    if (!command.trim()) {
      alert('请输入命令');
      return;
    }

    // 这里会调用真实的 Shizuku API
    setOutput(`执行命令: ${command}\n\n[模拟输出] 命令执行成功`);
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Shizuku Shell 执行</Text>

      <TouchableOpacity style={styles.button} onPress={checkAuthorization}>
        <Text style={styles.buttonText}>{authorized ? '✓ 已授权' : '授权 Shizuku'}</Text>
      </TouchableOpacity>

      <Text style={styles.label}>Shell 命令</Text>
      <TextInput
        style={[styles.input, styles.commandInput]}
        placeholder="输入 Shell 命令..."
        value={command}
        onChangeText={setCommand}
        multiline
      />

      <TouchableOpacity style={styles.button} onPress={executeCommand} disabled={!authorized}>
        <Text style={styles.buttonText}>执行命令</Text>
      </TouchableOpacity>

      {output && (
        <>
          <Text style={styles.label}>输出结果</Text>
          <View style={styles.outputBox}>
            <Text style={styles.outputText}>{output}</Text>
          </View>
        </>
      )}
    </ScrollView>
  );
}

// 主应用
export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={{
          headerShown: true,
          tabBarActiveTintColor: '#0A7EA4',
        }}
      >
        <Tab.Screen
          name="Chat"
          component={ChatScreen}
          options={{ title: '对话' }}
        />
        <Tab.Screen
          name="Settings"
          component={SettingsScreen}
          options={{ title: '设置' }}
        />
        <Tab.Screen
          name="Shizuku"
          component={ShizukuScreen}
          options={{ title: 'Shizuku' }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginTop: 12,
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
    fontSize: 14,
  },
  commandInput: {
    minHeight: 100,
    textAlignVertical: 'top',
  },
  button: {
    backgroundColor: '#0A7EA4',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 12,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  messageList: {
    flex: 1,
    marginBottom: 12,
  },
  messageBubble: {
    padding: 12,
    borderRadius: 12,
    marginBottom: 8,
    maxWidth: '80%',
  },
  userMessage: {
    backgroundColor: '#0A7EA4',
    alignSelf: 'flex-end',
  },
  aiMessage: {
    backgroundColor: '#f0f0f0',
    alignSelf: 'flex-start',
  },
  messageText: {
    fontSize: 14,
    color: '#333',
  },
  inputContainer: {
    flexDirection: 'row',
    gap: 8,
  },
  sendButton: {
    backgroundColor: '#0A7EA4',
    paddingHorizontal: 16,
    borderRadius: 8,
    justifyContent: 'center',
  },
  sendButtonText: {
    color: '#fff',
    fontWeight: '600',
  },
  modelItem: {
    padding: 12,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    marginBottom: 8,
  },
  selectedModel: {
    backgroundColor: '#0A7EA4',
    borderColor: '#0A7EA4',
  },
  modelText: {
    fontSize: 14,
    color: '#333',
  },
  outputBox: {
    backgroundColor: '#f5f5f5',
    padding: 12,
    borderRadius: 8,
    minHeight: 100,
  },
  outputText: {
    fontSize: 12,
    fontFamily: 'monospace',
    color: '#333',
  },
});
