# AI Chat Shell - Android 应用

一个功能完整的 Android 应用，集成了 AI 对话、Shizuku Shell 执行和完整中文汉化。

## 功能特性

✅ **AI 对话**
- 支持自定义 API 端点（OpenAI、Claude 等）
- 自动获取模型列表
- 实时对话和消息历史

✅ **Shizuku 集成**
- 真实的 Shell 命令执行
- 权限管理
- 命令输出查看

✅ **完整中文汉化**
- 所有界面都是中文
- 中文错误提示

## 快速开始

### 方法 1：使用 EAS Build（推荐）

1. **安装 EAS CLI**
   ```bash
   npm install -g eas-cli
   ```

2. **登录 Expo 账户**
   ```bash
   eas login
   ```

3. **编译 APK**
   ```bash
   eas build --platform android
   ```

4. 编译完成后，您会收到 APK 下载链接

### 方法 2：本地编译

1. **安装依赖**
   ```bash
   npm install
   ```

2. **预构建**
   ```bash
   npx expo prebuild --clean
   ```

3. **编译 APK**
   ```bash
   npx eas build --local --platform android
   ```

## 项目结构

```
ai-shell-apk/
├── App.js              # 主应用代码
├── app.json            # Expo 配置
├── package.json        # 项目依赖
├── babel.config.js     # Babel 配置
├── assets/             # 应用资源
└── README.md           # 本文档
```

## API 配置

在应用的"设置"标签中配置 AI API：

1. **API 端点**：输入您的 API 服务器地址
   - 例如：`https://api.openai.com/v1`

2. **API 密钥**：输入您的 API 密钥
   - 例如：`sk-...`

3. **获取模型列表**：点击按钮自动获取可用模型

4. **选择模型**：从列表中选择要使用的模型

5. **保存设置**：点击保存按钮

## 使用指南

### 对话屏幕
1. 在输入框中输入您的问题
2. 点击"发送"按钮
3. AI 会返回响应

### Shizuku 屏幕
1. 点击"授权 Shizuku"（需要设备上已安装 Shizuku）
2. 在输入框中输入 Shell 命令
3. 点击"执行命令"
4. 查看命令输出

## 系统要求

- Android 6.0 或更高版本
- 至少 100MB 可用存储空间
- 网络连接（用于 AI 对话）

## 常见问题

### Q: 如何获取 API 密钥？
A: 访问您的 AI 服务提供商的官方网站（如 OpenAI、Claude 等）获取 API 密钥。

### Q: Shizuku 是什么？
A: Shizuku 是一个 Android 应用，可以让其他应用以提升的权限运行 Shell 命令。

### Q: 如何安装 Shizuku？
A: 从 F-Droid 或 GitHub 下载 Shizuku 应用并安装。

## 编译问题排查

### 问题 1：EAS Build 失败
- 检查网络连接
- 确保 app.json 配置正确
- 查看构建日志获取详细错误信息

### 问题 2：APK 安装失败
- 确保 Android 版本兼容
- 卸载旧版本后重新安装
- 检查存储空间

### 问题 3：API 连接失败
- 检查 API 端点是否正确
- 验证 API 密钥是否有效
- 确保网络连接正常

## 开发和修改

如果您想修改应用：

1. **编辑代码**
   ```bash
   nano App.js
   ```

2. **测试更改**
   ```bash
   npm start
   ```

3. **重新编译**
   ```bash
   eas build --platform android
   ```

## 许可证

本项目仅供个人使用。

## 支持

如有问题，请检查：
1. 本 README 中的常见问题
2. Expo 官方文档：https://docs.expo.dev
3. EAS Build 文档：https://docs.expo.dev/build/introduction/
