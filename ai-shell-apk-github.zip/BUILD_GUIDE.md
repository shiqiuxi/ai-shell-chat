# AI Chat Shell - APK 编译指南

本指南将帮助您使用 EAS Build 云编译服务生成 APK 安装包。

## 📋 前置条件

1. **Expo 账户**
   - 访问 https://expo.dev
   - 点击"Sign Up"创建账户

2. **Node.js**
   - 下载并安装 Node.js（推荐 v16 或更高）
   - 访问 https://nodejs.org

3. **网络连接**
   - 稳定的互联网连接

## 🚀 快速编译步骤

### 第 1 步：安装 EAS CLI

打开终端/命令行，运行：

```bash
npm install -g eas-cli
```

### 第 2 步：登录 Expo 账户

```bash
eas login
```

按提示输入您的 Expo 账户邮箱和密码。

### 第 3 步：进入项目目录

```bash
cd /path/to/ai-shell-apk
```

### 第 4 步：编译 APK

```bash
eas build --platform android
```

### 第 5 步：等待编译完成

- 编译通常需要 5-10 分钟
- 您会看到一个链接，可以在浏览器中查看编译进度
- 编译完成后，您会收到 APK 下载链接

### 第 6 步：下载 APK

点击提供的链接下载 APK 文件。

## 📱 安装 APK

### 方法 1：使用 ADB（推荐）

```bash
adb install app-debug.apk
```

### 方法 2：直接安装

1. 将 APK 文件复制到手机
2. 使用文件管理器打开 APK
3. 按提示安装

### 方法 3：使用 Expo Go

1. 在手机上安装 Expo Go 应用
2. 在项目目录运行：`expo start`
3. 用 Expo Go 扫描二维码

## 🔧 常见问题

### 问题 1：EAS CLI 安装失败

**错误信息**：`npm ERR! code EACCES`

**解决方案**：
```bash
# 使用 sudo
sudo npm install -g eas-cli

# 或者修复 npm 权限
mkdir ~/.npm-global
npm config set prefix '~/.npm-global'
export PATH=~/.npm-global/bin:$PATH
npm install -g eas-cli
```

### 问题 2：登录失败

**错误信息**：`Authentication failed`

**解决方案**：
1. 确保 Expo 账户已创建
2. 检查邮箱和密码是否正确
3. 尝试重置密码：https://expo.dev/forgot-password

### 问题 3：编译失败

**错误信息**：`Build failed`

**解决方案**：
1. 检查网络连接
2. 查看详细错误日志
3. 确保 app.json 配置正确
4. 尝试清理缓存：`eas build --platform android --clear-cache`

### 问题 4：APK 安装失败

**错误信息**：`Installation failed`

**解决方案**：
1. 确保 Android 版本兼容（6.0 或更高）
2. 卸载旧版本：`adb uninstall com.shuoshuo.chat`
3. 检查存储空间
4. 尝试重新下载 APK

### 问题 5：编译速度慢

**原因**：首次编译需要下载依赖

**解决方案**：
1. 确保网络连接稳定
2. 耐心等待（通常 5-10 分钟）
3. 后续编译会更快

## 📊 编译配置说明

`eas.json` 文件中的配置：

```json
{
  "build": {
    "preview": {
      "android": {
        "buildType": "apk"
      }
    },
    "production": {
      "android": {
        "buildType": "apk"
      }
    }
  }
}
```

- **preview**：用于测试的构建配置
- **production**：用于发布的构建配置
- **buildType: "apk"**：输出 APK 格式（而不是 AAB）

## 🔐 签名配置

EAS Build 会自动为您签名 APK。如果您想使用自己的签名密钥：

1. 生成签名密钥：
   ```bash
   keytool -genkey -v -keystore my-release-key.keystore -keyalg RSA -keysize 2048 -validity 10000 -alias my-key-alias
   ```

2. 在 EAS 中配置：
   ```bash
   eas credentials
   ```

3. 按提示上传签名密钥

## 📝 修改应用

如果您想修改应用代码：

1. **编辑 App.js**
   ```bash
   nano App.js
   ```

2. **修改配置**
   编辑 `app.json` 中的应用名称、图标等

3. **重新编译**
   ```bash
   eas build --platform android
   ```

## 🎯 下一步

1. 按照本指南编译 APK
2. 在手机上安装和测试
3. 配置 AI API 和 Shizuku
4. 开始使用应用

## 📞 获取帮助

- **EAS Build 文档**：https://docs.expo.dev/build/introduction/
- **Expo 文档**：https://docs.expo.dev
- **GitHub Issues**：https://github.com/expo/expo/issues

---

**祝您编译顺利！** 🎉
