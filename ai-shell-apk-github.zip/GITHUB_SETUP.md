# GitHub Actions 自动编译指南

本指南将帮助您使用 GitHub Actions 自动编译 APK。

## 📋 前置条件

1. **GitHub 账户**
   - 访问 https://github.com
   - 注册免费账户

2. **Expo 账户**
   - 访问 https://expo.dev
   - 注册免费账户

## 🚀 设置步骤

### 第 1 步：创建 GitHub 仓库

1. 登录 GitHub
2. 点击右上角 "+" → "New repository"
3. 输入仓库名称：`ai-shell-chat`
4. 选择 "Public"（公开）
5. 点击 "Create repository"

### 第 2 步：上传项目文件

#### 方法 A：使用 GitHub 网页界面（推荐）

1. 在新建的仓库页面，点击 "Add file" → "Upload files"
2. 将项目文件拖到上传区域
3. 点击 "Commit changes"

#### 方法 B：使用 Git 命令

```bash
# 克隆仓库
git clone https://github.com/YOUR_USERNAME/ai-shell-chat.git
cd ai-shell-chat

# 复制项目文件到此目录
cp -r /path/to/ai-shell-apk/* .

# 提交文件
git add .
git commit -m "Initial commit"
git push origin main
```

### 第 3 步：获取 Expo Token

1. 访问 https://expo.dev/settings/tokens
2. 点击 "Create Token"
3. 输入 token 名称（例如：GitHub Actions）
4. 复制生成的 token

### 第 4 步：添加 GitHub Secret

1. 进入您的仓库页面
2. 点击 "Settings" → "Secrets and variables" → "Actions"
3. 点击 "New repository secret"
4. 名称：`EXPO_TOKEN`
5. 值：粘贴您的 Expo Token
6. 点击 "Add secret"

### 第 5 步：触发编译

#### 方法 1：自动编译（推荐）

只需推送代码到 main 分支：

```bash
git push origin main
```

GitHub Actions 会自动开始编译。

#### 方法 2：手动编译

1. 进入仓库页面
2. 点击 "Actions" 标签
3. 选择 "Build APK" 工作流
4. 点击 "Run workflow"
5. 点击 "Run workflow" 按钮

### 第 6 步：下载 APK

#### 方法 1：从 Artifacts 下载

1. 进入 "Actions" 标签
2. 点击最新的编译任务
3. 向下滚动找到 "Artifacts" 部分
4. 点击 "app-apk" 下载

#### 方法 2：从 Releases 下载

1. 进入仓库主页
2. 点击右侧 "Releases"
3. 点击最新版本
4. 下载 `app-release.apk`

## 📊 编译进度查看

1. 进入仓库的 "Actions" 标签
2. 可以看到所有编译任务
3. 点击任务查看详细日志

编译通常需要 10-20 分钟。

## ⚠️ 常见问题

### 问题 1：编译失败

**错误信息**：`EXPO_TOKEN not found`

**解决方案**：
1. 检查是否添加了 `EXPO_TOKEN` secret
2. 确保 token 值正确
3. 重新运行工作流

### 问题 2：编译超时

**原因**：首次编译需要下载依赖

**解决方案**：
1. 耐心等待（通常 15-20 分钟）
2. 后续编译会更快
3. 如果仍然超时，尝试增加超时时间

### 问题 3：APK 文件找不到

**原因**：编译失败或输出路径不同

**解决方案**：
1. 检查编译日志查看错误
2. 确保 `eas.json` 配置正确
3. 尝试手动编译测试

### 问题 4：无法登录 Expo

**错误信息**：`Authentication failed`

**解决方案**：
1. 检查 `EXPO_TOKEN` 是否过期
2. 重新生成新的 token
3. 更新 GitHub Secret

## 🔧 修改应用

如果您想修改应用：

1. **编辑代码**
   ```bash
   nano App.js
   ```

2. **提交更改**
   ```bash
   git add .
   git commit -m "Update: description of changes"
   git push origin main
   ```

3. **自动编译**
   GitHub Actions 会自动开始新的编译

## 📝 工作流说明

`build-apk.yml` 文件定义了以下步骤：

1. **Checkout** - 获取最新代码
2. **Setup Node.js** - 安装 Node.js
3. **Install dependencies** - 安装项目依赖
4. **Setup EAS** - 安装 EAS CLI
5. **Build APK** - 使用 EAS Build 编译 APK
6. **Upload Artifacts** - 上传到 GitHub Artifacts
7. **Create Release** - 创建 GitHub Release
8. **Upload Release Asset** - 上传 APK 到 Release

## 🎯 下一步

1. 创建 GitHub 仓库
2. 上传项目文件
3. 获取 Expo Token
4. 添加 GitHub Secret
5. 推送代码触发编译
6. 等待编译完成
7. 下载 APK

## 📞 获取帮助

- **GitHub Actions 文档**：https://docs.github.com/en/actions
- **Expo 文档**：https://docs.expo.dev
- **EAS Build 文档**：https://docs.expo.dev/build/introduction/

---

**祝您编译顺利！** 🎉
